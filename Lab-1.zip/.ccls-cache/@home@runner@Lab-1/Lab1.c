#include <stdio.h>

/*prototypes*/ 
 void printFirstName();
 void printLastName(); 

int main(void) {
  
  /*call to function*/ 
  printFirstName(), printLastName();
  
  /*program*/
  printf("invites you to her graduation party on December 1st, 2023. Please RSVP to ");
  printFirstName();
  printf("ASAP.\n");
    printf(" - ");
    printFirstName(), printLastName();

  printf("\n");
   printf("\n");
    printf("Name: ");
    printFirstName(), printLastName();
  printf("\n");
  printf("\n");
    printf("From: Cleveland, Oklahoma");
  printf("\n");
  printf("\n");
    printf("About Me: I am 19 and a Sophomore at TCC majoring in Computer Information Systems. I have a pet chinchilla and her name is Zelda. Recently I have started going to the gym and some other hobbies of mine include playing the flute, drawing, and singing.");
  
  return 0;
}

/*Define Function*/ 
  void printFirstName() 
{
  printf("Alexis ");
}
  void printLastName()
{
  printf("Wilson ");
}