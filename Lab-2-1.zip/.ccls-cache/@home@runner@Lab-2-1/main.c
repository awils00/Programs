#include <stdio.h>

int main(void) {
  float score1, score2, score3;   
  double ave;

  
  printf("Please enter three exam scores:");
  
  
  scanf("%f",&score1); /*scan formatted string*/
  scanf("%f",&score2);
  scanf("%f",&score3);

  printf("\nFirst Exam: %.2f", score1); printf("%%");
  printf("\nSecond Exam: %.2f", score2); printf("%%");
  printf("\nThird Exam:%.2f", score3); printf("%%");
  printf("\n--------------------- \n");

  ave = (score1 + score2 + score3)/3;
  printf("Average: %lf", ave); printf("%%");


  
  return 0;
}
