#include <stdio.h>

void print_benefits(int n);
int main(void) {
  
  int n = 0;  
  int y1;
  int s1, s2, s3; 
  double ave1; 
  double monthly_benefit; 
  
  
  while( n < 3)
    
    { 
      n = n + 1; 

      printf("Enter retiree %d's years of service and 3 highest salaries. \n", n);
      scanf("%d", &y1); scanf("%d",&s1); scanf("%d",&s2); scanf("%d",&s3); 

      ave1 = (s1+s2+s3)/3; 
      monthly_benefit = ave1 * .02 * y1 / 12;

      
     printf("Retiree %d will recieve $%.2lf/month\n\n", n , monthly_benefit);}
       
  return 0;
}